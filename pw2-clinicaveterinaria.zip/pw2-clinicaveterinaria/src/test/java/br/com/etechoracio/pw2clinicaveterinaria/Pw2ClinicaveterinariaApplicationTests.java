package br.com.etechoracio.pw2clinicaveterinaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw2ClinicaveterinariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
