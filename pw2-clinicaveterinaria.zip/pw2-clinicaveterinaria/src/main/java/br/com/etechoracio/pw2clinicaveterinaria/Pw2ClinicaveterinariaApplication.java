package br.com.etechoracio.pw2clinicaveterinaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw2ClinicaveterinariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw2ClinicaveterinariaApplication.class, args);
	}

}
